# As Veda India Landing Page
Edit index.html on GitHub (pencil icon) and commit; the site updates in ~1 minute.
